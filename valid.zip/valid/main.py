#!/usr/bin/python
# -*- coding: utf-8 -*-
#============== Modules ==============#
import os
from requests import get
from pyfiglet import Figlet
from rich.console import Console
from concurrent.futures import ThreadPoolExecutor
from rich import print
from datetime import datetime
import json
import ctypes
import sys
import tkinter as tk
from tkinter import filedialog

#============ Create Folder ===============#
try:
    os.mkdir('Results')
except:
    pass

#===========================================#
class Bot():
    def __init__(self):
        self.valid_numbers = 0
        self.invalid_numbers = 0
        self.checked_numbers = 0

    def Checker(self, i):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0",
            "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "https://telnyx.com/",
            "origin": "https://telnyx.com",
        }

        try:
            response = get(url=f"https://api.telnyx.com/anonymous/v2/number_lookup/{i}", headers=headers, allow_redirects=False)
            data = response.json()['data']

            if data['valid_number']:
                carrier_name = data['carrier']['name']
                self.valid_numbers += 1
                print(f"[green][{datetime.now().strftime('%H:%M:%S')}] Valid Number: {i} | Carrier: {carrier_name}[/green]")
                with open(f"Results/{carrier_name}.txt", "a") as save_file:
                    save_file.write(f"\n{i}")
            else:
                self.invalid_numbers += 1
                print(f"[red][{datetime.now().strftime('%H:%M:%S')}] Invalid Number: {i}[/red]")
                with open("Results/Invalids.txt", "a") as save_invalid:
                    save_invalid.write(f"\n{i}")

            self.checked_numbers += 1
            self.update_title()
        except Exception as e:
            self.update_title()

    def update_title(self):
        title = f"Valid Numbers: {self.valid_numbers} | Invalid Numbers: {self.invalid_numbers} | Checked Numbers: {self.checked_numbers} | WeedyDev"
        if os.name == 'nt':
            ctypes.windll.kernel32.SetConsoleTitleW(title)
        else:
            sys.stdout.write(f'\x1b]2;{title}\x07')

    def choose_file(self):
        root = tk.Tk()
        root.withdraw()
        file_path = filedialog.askopenfilename(title="Choose the file to check")
        return file_path

if __name__ == '__main__':
    bot = Bot()
    console = Console()

    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        f = Figlet(font="standard")
        console.print(f.renderText("WeedyDev"), style="green")
        console.print("[bold magenta]By WeedyDev | @WeedyDev | Channel:- https://t.me/+R0ThhXb7z6MxNWM1 [/bold magenta]")
        console.print('')

        try:
            inpFile = bot.choose_file()
            threads = []
            with open(inpFile) as NumList:
                argFile = NumList.read().splitlines()
                total_numbers = len(argFile)
            with ThreadPoolExecutor(max_workers=50) as executor:  # Defaulted to 50 threads
                for data in argFile:
                    threads.append(executor.submit(bot.Checker, data))

            # Wait for all threads to complete
            for thread in threads:
                thread.result()

            bot.update_title()
        except Exception as e:
            console.print(e)

        input("Press Enter to exit...")
        break