Tool Number Validator

Created By @WeedyDev

Join us https://t.me/+R0ThhXb7z6MxNWM1

Coded in Python3

Usage:
pip install -r requirements.txt
python main.py