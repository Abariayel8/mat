<?php
#SMTP SETUP //
$hostname[]		= 'smtp.website.com'; // HOST SMTP		
$username[] 	= 'suporte@noreply.com'; // USERNAME SMTP
$password[] 	= 'nothinghere'; // PASSWORD SMTP
$secure[] 		= 'tls'; // TLS / SSL
$port[] 		= '587'; // PORT SMTP

#STILLAN MU
$fromname 		= 'Chase Online';   // FROM NAME
$frommail 		= 'suporte@noreply.com'; // FROM EMAIL
$subject 		= 'A New Secure Message From Chase, We cant validate your chase. ID:##num5##'; // SUBJECT LETTER

#SENDING SETTINGS
$priority 		 = 0; // 1 = HIGH | 0 = NORMAL | EMAIL PRIORITY
$sensoremail 	 = 0; // 1 = ON | 0 = OFF | SENSOR FROM EMAIL
$duplicate 		 = 0; // 1 = ON | 0 = OFF | HAPUS DUPLICATE MAILIST
$removeaftersend = 1; // 1 = ON | 0 = OFF | HAPUS EMAIL YANG SUDAH TERKIRIM
$delay 			 = 0; // DELAY PER DETIK
$email 			 = 0; // DELAY DI BERAPA EMAIL ?

#LETTER SETTING
$mailtype 		 = '';   // TIPE EMAIL : microsoft / google / yahoo
$letter 		 = 'test.html'; // FILE LETTER
$attachment 	 = '';			  // FILE ATTACHMENT
$emaillist 		 = '3.txt';	  // FILE EMAILIST
$language 		 = 'US'; 		  // US / DE / FR / ETC			
$link[] 		 = 'google.com';  // LINK SCAM TANPA HTTPS://

?>







